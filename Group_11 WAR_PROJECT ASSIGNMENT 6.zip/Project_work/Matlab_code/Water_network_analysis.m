clc;
clear;
close all;

% WATER DISTRIBUTION NETWORK ANALYSIS
% EPANET results: 6 junctions

% Junction names
junctions = {'Junc 2','Junc 3','Junc 4', ...
             'Junc 5','Junc 6','Junc 7'};

% Demand at each junction (L/s)
demand = [2 2 2 3 2 2];

% Hydraulic head (m)
head = [39.29 39.29 39.29 39.30 39.30 39.30];

% Pressure head (m of water)
pressure = [19.29 19.29 19.29 9.30 19.30 19.30];

% Display results in the Command Window
results = table(junctions', demand', head', pressure', ...
    'VariableNames', {'Junction','Demand_LPS', ...
    'Head_m','Pressure_m'});

disp('WATER DISTRIBUTION NETWORK RESULTS');
disp(results);

% GRAPH 1: Pressure at each junction
figure;
bar(pressure);
set(gca,'XTick',1:6,'XTickLabel',junctions);
xlabel('Junction');
ylabel('Pressure Head (m)');
title('Pressure Distribution in the Network');
grid on;

% GRAPH 2: Demand at each junction
figure;
bar(demand);
set(gca,'XTick',1:6,'XTickLabel',junctions);
xlabel('Junction');
ylabel('Demand (L/s)');
title('Water Demand Distribution');
grid on;

% Identify the junction with the lowest pressure
[minPressure, index] = min(pressure);

fprintf('Lowest pressure: %.2f m\n', minPressure);
fprintf('Junction requiring attention: %s\n', ...
    junctions{index});
% PIPE ANALYSIS USING EPANET RESULTS

pipeNames = {'Pipe 1','Pipe 2','Pipe 3','Pipe 4', ...
             'Pipe 5','Pipe 6','Pipe 7','Pipe 8', ...
             'Pipe 9','Pipe 10','Pipe 11'};

% Flow in litres per second (L/s)
flow = [0.12 -1.88 -3.88 -5.88 -2.67 ...
        -4.17 -2.45 -2.22 -2.04 -3.21 -2.96];

% Velocity in metres per second (m/s)
velocity = [1.03 0.01 0.02 0.03 0.04 ...
            0.06 0.31 0.28 0.26 0.41 0.38];

% Unit headloss in metres per kilometre (m/km)
headloss = [151.77 0 0 0 0.01 0.02 ...
            1.41 1.17 1.01 2.33 2.00];

% Display pipe results
pipeResults = table(pipeNames', flow', velocity', headloss', ...
    'VariableNames', {'Pipe','Flow_LPS', ...
    'Velocity_mps','UnitHeadloss_m_per_km'});

disp('PIPE HYDRAULIC RESULTS');
disp(pipeResults);

% GRAPH 3: Signed flow in each pipe
figure;
bar(flow);
yline(0,'k-');
xlabel('Pipe');
ylabel('Flow (L/s)');
title('EPANET Pipe Flow Distribution');
set(gca,'XTick',1:11,'XTickLabel',pipeNames);
xtickangle(45);
grid on;

% GRAPH 4: Velocity in each pipe
figure;
bar(velocity);
xlabel('Pipe');
ylabel('Velocity (m/s)');
title('Water Velocity in Pipes');
set(gca,'XTick',1:11,'XTickLabel',pipeNames);
xtickangle(45);
grid on;

% GRAPH 5: Unit headloss in each pipe
figure;
bar(headloss);
xlabel('Pipe');
ylabel('Unit Headloss (m/km)');
title('Headloss Distribution in Pipes');
set(gca,'XTick',1:11,'XTickLabel',pipeNames);
xtickangle(45);
grid on;

% Identify the highest velocity and headloss
[maxVelocity, iv] = max(velocity);
[maxHeadloss, ih] = max(headloss);

fprintf('Highest velocity: %.2f m/s in %s\n', ...
    maxVelocity, pipeNames{iv});

fprintf('Highest unit headloss: %.2f m/km in %s\n', ...
    maxHeadloss, pipeNames{ih});