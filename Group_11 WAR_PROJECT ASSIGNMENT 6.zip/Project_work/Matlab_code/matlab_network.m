clc;
clear;
close all;

% Node names
nodes = {'Reservoir 1', ...
         'Junc 2','Junc 3','Junc 4', ...
         'Junc 5','Junc 6','Junc 7', ...
         'Tank 8','Tank 9','Tank 10', ...
         'Tank 11','Tank 12'};

% Approximate node coordinates for plotting
% Columns are X and Y coordinates
XY = [0  1;    % Reservoir 1
      2  1;    % Junc 2
      4  1;    % Junc 3
      4  2;    % Junc 4
      6  2;    % Junc 5
      6  3;    % Junc 6
      6  0;    % Junc 7
      7  4;    % Tank 8
      9  4;    % Tank 9
      7 -1;    % Tank 10
      9 -1;    % Tank 11
      8  2];   % Tank 12

% Pipe connections: [starting node, ending node]
% These are illustrative connections.
% Replace them with your actual EPANET pipe endpoints.
pipes = [1 2;
         2 3;
         3 4;
         4 5;
         5 6;
         5 7;
         6 8;
         6 9;
         7 10;
         7 11;
         5 12];

% Draw the network
figure('Color','w');
hold on;

for k = 1:size(pipes,1)
    i = pipes(k,1);
    j = pipes(k,2);

    plot([XY(i,1), XY(j,1)], ...
         [XY(i,2), XY(j,2)], ...
         'b-', 'LineWidth', 2);

    % Pipe label at midpoint
    xm = (XY(i,1) + XY(j,1))/2;
    ym = (XY(i,2) + XY(j,2))/2;
    text(xm, ym, [' P' num2str(k)], ...
         'FontSize', 8, 'Color', 'k');
end

% Plot junctions
junctions = 2:7;
scatter(XY(junctions,1), XY(junctions,2), ...
        65, 'g', 'filled');

% Plot tanks
tanks = 8:12;
scatter(XY(tanks,1), XY(tanks,2), ...
        100, 'c', 'filled', 's');

% Plot reservoir
scatter(XY(1,1), XY(1,2), ...
        140, 'r', 'filled', '^');

% Label all nodes
for k = 1:length(nodes)
    text(XY(k,1)+0.1, XY(k,2)+0.12, ...
         nodes{k}, 'FontSize', 9);
end

title('EPANET Water Distribution Network');
xlabel('X coordinate');
ylabel('Y coordinate');

axis equal;
grid on;
box on;
hold off;