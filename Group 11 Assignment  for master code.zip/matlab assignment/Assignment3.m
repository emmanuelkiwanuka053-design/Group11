%importing images 
mango_leaf = imread("C:\Users\essie\OneDrive\Desktop\LEAVES\mango leaf.jpeg"); 
orange_leaf = imread("C:\Users\essie\OneDrive\Desktop\LEAVES\orange leaf.jpeg"); 
maize_leaf = imread("C:\Users\essie\OneDrive\Desktop\LEAVES\maize leaf.jpeg"); 
paw_paw_leaf = imread("C:\Users\essie\OneDrive\Desktop\LEAVES\paw paw leaf.jpeg"); 
rose_leaf = imread("C:\Users\essie\OneDrive\Desktop\LEAVES\Rose leaf.jpeg"); 
 
 
%sample 1 
leaves(1).Name = 'mango_leaf'; 
leaves(1).type = 'simple'; 
leaves(1).venetion = 'network'; 
leaves(1).margin = 'smooth'; 
leaves(1).apex = 'acute'; 
leaves(1).originalimage = (mango_leaf); 
 
%group photo of sample 1 
%processing of sample 2 
gray1 = im2gray(leaves(1).originalimage); 
enhanced1 = imadjust(gray1); 
bw1 = imbinarize(enhanced1); 
edges1 = edge(gray1,'canny'); 
  
%storing of sample 1 
leaves(1).processed.grayscale = gray1; 
leaves(1).processed.constrastenhanced = enhanced1; 
leaves(1).processed.binarymask = bw1; 
leaves(1).processed.edgedetection = edges1; 
 
 
%sample 2 
leaves(2).Name = 'orange_leaf'; 
leaves(2).type = 'simple'; 
leaves(2).venetion = 'network'; 
leaves(2).margin = 'entire'; 
leaves(2).apex = 'acute'; 
leaves(2).originalimage = (orange_leaf); 
 
%group photo of sample 2 
%processing of sample 2 
gray2 = im2gray(leaves(2).originalimage); 
enhanced2 = imadjust(gray2); 
bw2 = imbinarize(enhanced2); 
edges2 = edge(gray2,'canny'); 
  
%storing of sample 2 
leaves(2).processed.grayscale = gray2; 
leaves(2).processed.constrastenhanced = enhanced2; 
leaves(2).processed.binarymask = bw2; 
leaves(2).processed.edgedetection = edges2; 
 
%sample 3 
leaves(3).Name = 'maize_leaf'; 
leaves(3).type = 'simple'; 
leaves(3).venetion = 'parallel'; 
leaves(3).margin = 'rough'; 
leaves(3).apex = 'acute'; 
leaves(3).originalimage = (maize_leaf); 
 
%group photo of sample 3 
%processing of sample 3 
gray3 = rgb2gray(leaves(3).originalimage); 
enhanced3 = imadjust(gray3); 
bw3 = imbinarize(enhanced3); 
edges3 = edge(gray3,'sobel'); 
  
%storing of sample 3 
leaves(3).processed.grayscale = gray3; 
leaves(3).processed.constrastenhanced = enhanced3; 
leaves(3).processed.binarymask = bw3; 
leaves(3).processed.edgedetection = edges3; 
 
%sample 4 
leaves(4).Name = 'paw_paw_leaf'; 
leaves(4).type = 'compound'; 
leaves(4).venetion = 'network'; 
leaves(4).margin = 'rough'; 
leaves(4).apex = 'acute'; 
leaves(4).originalimage = (paw_paw_leaf); 
 
%group photo of sample 4 
%processing of sample 4 
gray4 = rgb2gray(leaves(4).originalimage); 
enhanced4 = imadjust(gray4); 
bw4 = imbinarize(enhanced4); 
edges4 = edge(gray4,'canny'); 
  
%storing of sample 4 
leaves(4).processed.grayscale = gray4; 
leaves(4).processed.constrastenhanced = enhanced4; 
leaves(4).processed.binarymask = bw4; 
leaves(4).processed.edgedetection = edges4; 
 
%sample 5 
leaves(5).Name = 'rose_leaf'; 
leaves(5).type = 'compound'; 
leaves(5).venetion = 'network'; 
leaves(5).margin = 'smooth'; 
leaves(5).apex = 'acute'; 
leaves(5).originalimage = (rose_leaf); 
 
%group photo of sample 5 
%processing of sample 5 
gray5 = rgb2gray(leaves(5).originalimage); 
enhanced5 = imadjust(gray5); 
bw5 = imbinarize(enhanced5); 
edges5 = edge(gray5,'sobel'); 
  
%storing of sample 5 
leaves(5).processed.grayscale = gray5; 
leaves(5).processed.constrastenhanced = enhanced5; 
leaves(5).processed.binarymask = bw5; 
leaves(5).processed.edgedetection = edges5; 
  
save