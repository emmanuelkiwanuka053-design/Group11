BAR GRAPH CODE 
x=(studentsinMyProgram.NAME); 
y=(studentsinMyProgram.AGE); 
bar(x,y); 
title('Students name against Age'); 
xlabel('Students name'); 
ylabel('Age'); 
grid on; 
BARH GRAPH CODE 
x=(studentsinMyProgram.NAME); 
y=(studentsinMyProgram.AGE); 
barh(x,y); 
title('Students name against Age'); 
xlabel('Students name'); 
ylabel('Age'); 
grid on; 
BOXPLOT CODE 
X=(studentsinMyProgram.CGPA); 
boxplot(X); 
title('Box plot showing CGPA'); 
grid on; 
ERRORBAR CODE 
x=(studentsinMyProgram.CGPA); 
y=(studentsinMyProgram.WEIGHT); 
errorbar(x,y); 
title('CGPA of student against Weight'); 
xlabel('CGPA of students'); 
ylabel('Weight of students'); 
grid on; 
SEMILOGX CODE 
x=(studentsinMyProgram.CGPA); 
y=exp(x) 
semilogx(x,y); 
title('Semilogx plot showing CGPA'); 
grid on; 
x=(studentsinMyProgram.AGE); 
SCATTER CODE 
y=(studentsinMyProgram.HEIGHT); 
scatter(x,y); 
title('Age of student against height'); 
xlabel('Age of students'); 
ylabel('Height of students'); 
grid on; 
STEM CODE 
x=(studentsinMyProgram.CGPA); 
y=(studentsinMyProgram.WEIGHT); 
stem(x,y); 
title('Students CGPA against Weight'); 
xlabel('Students CGPA'); 
ylabel('Weight'); 
grid on; 
PARETO CODE 
X=(studentsinMyProgram.CGPA); 
pareto(X); 
title('pareto showing CGPA'); 
grid on; 
PIE CHART CODE 
X=(studentsinMyProgram.CGPA); 
pie(X); 
title('pie chart showing CGPA of students'); 
PIECHART WITH PERCENT LABELS CODE 
X=(studentsinMyProgram.CGPA); 
Y=(studentsinMyProgram.NAME); 
pie(X,Y); 
title('pie chart with percent labels'); 
STAIRS PLOT 
X=(studentsinMyProgram.WEIGHT); 
Y=(studentsinMyProgram.HEIGHT); 
stairs(X,Y); 
title('step plot'BAR GRAPH CODE 
x=(studentsinMyProgram.NAME); 
y=(studentsinMyProgram.AGE); 
bar(x,y); 
title('Students name against Age'); 
xlabel('Students name'); 
ylabel('Age'); 
grid on; 
BARH GRAPH CODE 
x=(studentsinMyProgram.NAME); 
y=(studentsinMyProgram.AGE); 
barh(x,y); 
title('Students name against Age'); 
xlabel('Students name'); 
ylabel('Age'); 
grid on; 
BOXPLOT CODE 
X=(studentsinMyProgram.CGPA); 
boxplot(X); 
title('Box plot showing CGPA'); 
grid on; 
ERRORBAR CODE 
x=(studentsinMyProgram.CGPA); 
y=(studentsinMyProgram.WEIGHT); 
errorbar(x,y); 
title('CGPA of student against Weight'); 
xlabel('CGPA of students'); 
ylabel('Weight of students'); 
grid on; 
SEMILOGX CODE 
x=(studentsinMyProgram.CGPA); 
y=exp(x) 
semilogx(x,y); 
title('Semilogx plot showing CGPA'); 
grid on; 
x=(studentsinMyProgram.AGE); 
SCATTER CODE 
y=(studentsinMyProgram.HEIGHT); 
scatter(x,y); 
title('Age of student against height'); 
xlabel('Age of students'); 
ylabel('Height of students'); 
grid on; 
STEM CODE 
x=(studentsinMyProgram.CGPA); 
y=(studentsinMyProgram.WEIGHT); 
stem(x,y); 
title('Students CGPA against Weight'); 
xlabel('Students CGPA'); 
ylabel('Weight'); 
grid on; 
PARETO CODE 
X=(studentsinMyProgram.CGPA); 
pareto(X); 
title('pareto showing CGPA'); 
grid on; 
PIE CHART CODE 
X=(studentsinMyProgram.CGPA); 
pie(X); 
title('pie chart showing CGPA of students'); 
PIECHART WITH PERCENT LABELS CODE 
X=(studentsinMyProgram.CGPA); 
Y=(studentsinMyProgram.NAME); 
pie(X,Y); 
title('pie chart with percent labels'); 
STAIRS PLOT 
X=(studentsinMyProgram.WEIGHT); 
Y=(studentsinMyProgram.HEIGHT); 
stairs(X,Y); 
title('step plot')