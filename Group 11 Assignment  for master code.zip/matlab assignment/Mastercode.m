%master code
%list of the assignment files
Assignments = {
    'Assignment1.m'
    'Assignment2.m'
    'Assignment3.m'
    };
%loop through each assignment and run it
for i = 1:length(Assignments)
    fprintf('Running %s...\n', Assignments{i});
    run(Assignments{i});
    pause(2);
end
fprintf('All assignments executed.\n');